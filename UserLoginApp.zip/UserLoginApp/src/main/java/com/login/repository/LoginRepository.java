package com.login.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.login.model.User;

public interface LoginRepository extends CrudRepository<User, String>{

	
}

