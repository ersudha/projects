package com.login.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import com.login.model.User;
import com.login.repository.LoginRepository;

public class LoginService {
	
	@Autowired
	LoginRepository loginRepository;

	private List<User> topics = new ArrayList<User>(Arrays.asList(new User("Sudha", "Kumari"),
			new User("Niharika", "Sharma")
			));
	
	public List<User> getAllUsers() {
		List<User> users = new ArrayList<>();
		loginRepository.findAll().forEach(users :: add);
		return users;
		
	}
	
public User validateUser(User user, HttpServletRequest request) {
	HttpSession session = request.getSession();
	String username= request.getParameter("username");
	String password=request.getParameter("password");
	try {
		if(username!=null && password !=null) {
			if(!user.getUsername().equals(user.getPassword())){
				System.out.println("Not matched");
			}else {
				System.out.println("matched");
			}
		}
	}catch(Exception e ) {
		throw e;
	}
	return user;
	    
}
	
	
}
